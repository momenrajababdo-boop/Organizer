Organizer Android build

This project includes a GitHub Actions workflow at .github/workflows/android-apk.yml.
After the project is pushed to a GitHub repository, the workflow builds a debug APK.
Open the repository's Actions tab, choose "Build Organizer APK", run workflow,
and download the "Organizer-APK" artifact from the completed run.

This workflow creates a debug APK for testing. A signed release APK/AAB for public
Google Play publishing requires a release signing key and store configuration.
