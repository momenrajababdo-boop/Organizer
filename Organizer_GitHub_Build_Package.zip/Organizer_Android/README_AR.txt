Organizer — مشروع Android Studio

هذا مجلد مشروع أندرويد مبدئي يغلّف نسخة Organizer الحالية داخل WebView.

طريقة فتحه:
1) فك ضغط Organizer_Android_Project.zip.
2) افتح Android Studio واختر Open ثم اختر مجلد Organizer_Android.
3) انتظر مزامنة Gradle وتنزيل Android Gradle Plugin ومكونات Android SDK المطلوبة.
4) من Build اختر Build APK(s).

إعدادات المشروع:
- اسم التطبيق: Organizer
- Package: com.organizer.app
- Minimum Android: 6.0 (API 23)
- Target/Compile SDK: 35
- واجهة Organizer محفوظة داخل app/src/main/assets/index.html.

ملاحظات مهمة:
- هذا مصدر مشروع Android Studio وليس APK جاهزًا.
- لم يتم بناء APK أو اختباره على جهاز؛ بيئة الإنشاء الحالية لا تحتوي Android SDK أو Gradle.
- بيانات التطبيق الحالية تُحفظ محليًا في WebView عبر التخزين المحلي.
- الإشعارات الموثوقة أثناء إغلاق التطبيق، ومساعد الذكاء الاصطناعي الحقيقي، ومواقيت الصلاة التلقائية تحتاج تنفيذًا وربطًا إضافيًا.
