// Organizer AI backend — Cloudflare Worker
// Configure OPENAI_API_KEY as a Worker secret. Optional: OPENAI_MODEL (default gpt-5.5).
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8"
};
function json(body, status=200) {
  return new Response(JSON.stringify(body), {status, headers:cors});
}
function extractText(data) {
  if (typeof data.output_text === "string" && data.output_text.trim()) return data.output_text.trim();
  const parts=[];
  for (const item of (data.output || [])) {
    if (item.type === "message") {
      for (const c of (item.content || [])) if (c.type === "output_text" && c.text) parts.push(c.text);
    }
  }
  return parts.join("\n").trim();
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null,{status:204,headers:cors});
    if (request.method !== "POST" || url.pathname !== "/chat") return json({error:"المسار غير موجود."},404);
    if (!env.OPENAI_API_KEY) return json({error:"الخادم لم يتم إعداد مفتاح الذكاء الاصطناعي بعد."},503);
    let body;
    try { body=await request.json(); } catch { return json({error:"بيانات الطلب غير صالحة."},400); }
    if (!Array.isArray(body.messages) || body.messages.length < 1) return json({error:"اكتب رسالة أولًا."},400);
    const messages=body.messages.slice(-12).map(m=>({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0,4000)
    })).filter(m=>m.content.trim());
    if (!messages.length) return json({error:"الرسالة فارغة."},400);
    const tasks=Array.isArray(body.tasks) ? body.tasks.slice(0,30).map(t=>`- ${String(t.text||"").slice(0,160)}${t.time ? " — "+String(t.time).slice(0,8) : ""}`).join("\n") : "";
    const instructions = [
      "أنت مساعد Organizer لتنظيم الحياة اليومية. تحدث بالعربية المصرية الواضحة والمهذبة، إلا إذا طلب المستخدم لغة أخرى.",
      "ساعد في التخطيط وتقسيم المهام وترتيب الأولويات وتقديم اقتراحات عملية قصيرة. لا تدّع أنك أضفت أو عدّلت مهمة داخل التطبيق؛ أنت تقدم اقتراحات فقط.",
      "إذا كانت المهام الحالية متاحة، استخدمها كسياق ولا تخترع مواعيد أو التزامات. اسأل سؤالًا واحدًا فقط إذا كانت معلومة أساسية ناقصة.",
      "كن مشجعًا دون مبالغة، ولا تطلب كلمات مرور أو مفاتيح أو بيانات مالية حساسة."
    ].join("\n");
    const input=[{role:"user",content:"المهام غير المنجزة حاليًا في Organizer:\n"+(tasks||"لا توجد مهام مسجلة.")},...messages];
    let upstream;
    try {
      upstream=await fetch("https://api.openai.com/v1/responses",{
        method:"POST",
        headers:{"Authorization":"Bearer "+env.OPENAI_API_KEY,"Content-Type":"application/json"},
        body:JSON.stringify({model:env.OPENAI_MODEL||"gpt-5.5",instructions,input,max_output_tokens:700,store:false})
      });
    } catch { return json({error:"تعذر الوصول إلى خدمة الذكاء الاصطناعي. حاول لاحقًا."},502); }
    const data=await upstream.json().catch(()=>({}));
    if (!upstream.ok) {
      const msg=data?.error?.message || "خدمة الذكاء الاصطناعي رفضت الطلب.";
      return json({error:String(msg).slice(0,300)},upstream.status===429?429:502);
    }
    const reply=extractText(data);
    if (!reply) return json({error:"لم يصل رد نصي من الخدمة."},502);
    return json({reply});
  }
};
