package com.momen.organizer;
import android.app.*;import android.os.*;import android.content.*;import android.webkit.*;import android.widget.*;import org.json.*;import java.text.*;import java.util.*;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b); if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},1);
 WebView w=new WebView(this);w.setBackgroundColor(0xff101b2d);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);w.setWebChromeClient(new WebChromeClient());w.addJavascriptInterface(new Bridge(this),"OrganizerNative");w.loadUrl("file:///android_asset/index.html");setContentView(w); ReminderReceiver.createChannel(this);}
 public static class Bridge{
 Context c;Bridge(Context c){this.c=c;}
 @JavascriptInterface public void updateTasks(String json){try{SharedPreferences p=c.getSharedPreferences("org_widget",0);p.edit().putString("tasks",json).apply();OrganizerWidget.updateAll(c);schedule(json);}catch(Exception e){}}
 void schedule(String json){try{JSONArray a=new JSONArray(json);AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE);for(int i=0;i<500;i++){Intent old=new Intent(c,ReminderReceiver.class);old.putExtra("id",i);PendingIntent pi=PendingIntent.getBroadcast(c,i,old,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}for(int i=0;i<a.length();i++){JSONObject t=a.getJSONObject(i);String time=t.optString("time","");if(time.length()<10||t.optBoolean("done"))continue;try{String v=time.replace("T"," ");SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);f.setTimeZone(TimeZone.getDefault());long ms=f.parse(v).getTime();if(ms<=System.currentTimeMillis())continue;Intent in=new Intent(c,ReminderReceiver.class).putExtra("id",i).putExtra("title",t.optString("name","مهمة Organizer"));PendingIntent pi=PendingIntent.getBroadcast(c,i,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,ms,pi);}catch(Exception ex){}}}catch(Exception e){}}
 }
}
