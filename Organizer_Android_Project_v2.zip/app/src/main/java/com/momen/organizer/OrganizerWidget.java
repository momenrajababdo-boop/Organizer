package com.momen.organizer;
import android.appwidget.*;import android.content.*;import android.widget.*;import android.app.*;import org.json.*;
public class OrganizerWidget extends AppWidgetProvider{
 public static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);for(int id:m.getAppWidgetIds(new ComponentName(c,OrganizerWidget.class)))update(c,m,id);}
 public static void update(Context c,AppWidgetManager m,int id){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);String json=c.getSharedPreferences("org_widget",0).getString("tasks","[]");StringBuilder s=new StringBuilder();try{JSONArray a=new JSONArray(json);int count=0;for(int i=0;i<a.length()&&count<5;i++){JSONObject t=a.getJSONObject(i);if(!t.optBoolean("done")){s.append("• ").append(t.optString("name")).append("\n");count++;}}}catch(Exception e){}if(s.length()==0)s.append("لا توجد مهام غير مكتملة");v.setTextViewText(R.id.widget_tasks,s.toString());Intent in=new Intent(c,MainActivity.class);PendingIntent p=PendingIntent.getActivity(c,0,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(R.id.widget_root,p);v.setOnClickPendingIntent(R.id.widget_open,p);m.updateAppWidget(id,v);}
 public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);}
}
