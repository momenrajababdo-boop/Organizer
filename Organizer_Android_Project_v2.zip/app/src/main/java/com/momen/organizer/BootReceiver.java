package com.momen.organizer;
import android.content.*;
public class BootReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){String json=c.getSharedPreferences("org_widget",0).getString("tasks","[]");new MainActivity.Bridge(c).updateTasks(json);}}
