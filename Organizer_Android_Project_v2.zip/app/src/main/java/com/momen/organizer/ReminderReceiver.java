package com.momen.organizer;
import android.app.*;import android.content.*;import android.os.*;
public class ReminderReceiver extends BroadcastReceiver{
 static final String CH="organizer_tasks";
 public static void createChannel(Context c){if(Build.VERSION.SDK_INT>=26){NotificationChannel n=new NotificationChannel(CH,"تذكيرات Organizer",NotificationManager.IMPORTANCE_DEFAULT);((NotificationManager)c.getSystemService(NotificationManager.class)).createNotificationChannel(n);}}
 public void onReceive(Context c,Intent i){createChannel(c);String title=i.getStringExtra("title");if(title==null)title="موعد مهمة";Intent open=new Intent(c,MainActivity.class);PendingIntent p=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH):new Notification.Builder(c);b.setSmallIcon(android.R.drawable.ic_menu_today).setContentTitle("Organizer").setContentText("حان موعد: "+title).setAutoCancel(true).setContentIntent(p);((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(i.getIntExtra("id",0),b.build());}
}
