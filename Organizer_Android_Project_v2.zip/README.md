# Organizer Android
Android project built from Organizer_test_improved.html with native reminders and a home-screen widget.
Build using GitHub Actions workflow or Android Studio.
Reminder timing uses Android AlarmManager and notifications. On Android 13+, notification permission must be granted.
