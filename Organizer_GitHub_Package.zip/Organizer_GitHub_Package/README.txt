Organizer - GitHub upload package

UPLOAD:
1) Open your existing Organizer repository on GitHub.
2) Upload the CONTENTS of this folder to the repository root (not the enclosing folder).
3) Replace the old index.html with this package's index.html.
4) Add package.json, capacitor.config.json, and .github/workflows/android.yml at exactly those paths.
5) Commit to the main branch.

BUILD:
Open the repository Actions tab. Run "Build Organizer APK" (or let it run after the push).
When it finishes successfully, open the workflow run and download the artifact named Organizer-debug-apk.

IMPORTANT:
This package carries forward the uploaded Organizer_v2_work.html as index.html and adds the Android build workflow. It does not claim that every requested native feature is complete: reliable scheduled notifications while the app is closed, Android home-screen widgets, and a secure AI backend require additional native/backend implementation and testing. Do not publish this debug APK as a production release without testing.
