Organizer Android wrapper project (APK build via GitHub Actions)

1) Upload the contents of this folder to a GitHub repository (not the folder itself).
2) Open the repository's Actions tab.
3) Select "Build Organizer APK" and click Run workflow.
4) When completed, open the run and download artifact "Organizer-debug-apk".
5) Extract the artifact ZIP to obtain app-debug.apk.

This creates a debug APK from the supplied web app. It is not signed for Play Store release.
